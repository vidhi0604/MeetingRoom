package com.example.demo.service;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entity.MeetingRoom;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.interfaces.MeetingRoomService;
import com.example.demo.repository.MeetingRoomRepository;


@Service
@Transactional
public class MeetingRoomServiceImpl implements MeetingRoomService{

	@Autowired
	MeetingRoomRepository meetingRoomRepository;
	
	public MeetingRoomServiceImpl(MeetingRoomRepository meetingRoomRepository) {
		super();
		this.meetingRoomRepository = meetingRoomRepository;
	}
	

	public MeetingRoomServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}


	@Override
	public void createMeetingRoom(MeetingRoom meetingroom) {
		meetingRoomRepository.save(meetingroom);
		
	}

	@Override
	public List<MeetingRoom> getMeetingRoom() {
		return (List<MeetingRoom>) meetingRoomRepository.findAll();
	}

	@Override
	public MeetingRoom findById(int id) {
		 Optional<MeetingRoom> optMeetingRoom = meetingRoomRepository.findById(id); 
		    if (optMeetingRoom.isPresent()) {
		        return optMeetingRoom.get();
		    } else {
		       throw new ResourceNotFoundException("MeetingRoom", "Id", id);
		    }
	}

	@Override
	public MeetingRoom update(MeetingRoom meetingroom, int id) {
		Optional<MeetingRoom> optMeetingRoom = meetingRoomRepository.findById(id); 
	    if (optMeetingRoom.isPresent()) {
	    	MeetingRoom newRoom = optMeetingRoom.get();
	    	newRoom.setName(meetingroom.getName());
	    	newRoom.setCapacity(meetingroom.getCapacity());
	    	newRoom.setLocation(meetingroom.getLocation());

	        MeetingRoom updatedroom = meetingRoomRepository.save(newRoom);
	        return updatedroom;
	    } else {
	    	throw new ResourceNotFoundException("MeetingRoom", "Id",id);
	    }
	}

	@Override
	public Boolean deleteMeetingRoomById(int id) {
		Optional<MeetingRoom> optMeetingRoom = meetingRoomRepository.findById(id); 
	    if (optMeetingRoom.isPresent()) {
	    	meetingRoomRepository.delete(optMeetingRoom.get());
	        return true;
	    } else {
	       throw new ResourceNotFoundException("MeetingRoom", "Id",id);
	    }
	}

	@Override
	public List<MeetingRoom> findMeetingRoomAvailable(Date db, Date de) {
		System.out.println("db:"+db+"de::"+de);
		return (List<MeetingRoom>) meetingRoomRepository.findMeetingRoomAvailable(db, de);
	}


}
