package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Reservations;
import com.example.demo.interfaces.ReservationService;


@RestController
@RequestMapping("/reservation")
public class ReservationsController {
	
	@Autowired
    private ReservationService reservationServiceImpl;
	
	@RequestMapping(value = "/get",  method = RequestMethod.GET, produces = "application/json")
	public List<Reservations> getAllReservations() {
        List<Reservations> rooms = reservationServiceImpl.getReservations();
        return rooms;
	}
		
	@DeleteMapping(value="/{id}", headers ="Accept=application/json")
    public ResponseEntity<String> deleteUser(@PathVariable("id") int id){
		Reservations reservation = reservationServiceImpl.findById(id);
        if (reservation == null) {
            return new ResponseEntity<String>("No such Reservation", HttpStatus.NOT_FOUND);
        }
        reservationServiceImpl.deleteReservationsById(id);
        return new ResponseEntity<String>("Reservation Deleted", HttpStatus.NO_CONTENT);
    }

	@PostMapping(value="/book",headers="Accept=application/json")
    public ResponseEntity<String> createReservation(@RequestBody Reservations reservation){   						
        Reservations r = reservationServiceImpl.createReservation(reservation);
        if(r != null) {
        	return new ResponseEntity<String>("Booking Created Successfully With Bookingid :"+r.getReservationId(), HttpStatus.CREATED);
        } else
        	return new ResponseEntity<String>("Failed to Book", HttpStatus.NO_CONTENT);
    }


}