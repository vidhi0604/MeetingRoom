package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entity.MeetingRoom;
import com.example.demo.entity.Reservations;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.interfaces.ReservationService;
import com.example.demo.repository.MeetingRoomRepository;
import com.example.demo.repository.ReservationsRepository;


@Service
@Transactional
public class ReservationsServiceImpl  implements ReservationService{

	@Autowired
	ReservationsRepository reservationsRepository;
	
	@Autowired
	MeetingRoomRepository meetingRoomRepository;

	public ReservationsServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ReservationsServiceImpl(com.example.demo.repository.ReservationsRepository reservationsRepository) {
		super();
		reservationsRepository = reservationsRepository;
	}

	@Override
	public List<Reservations> getReservations() {
		return (List<Reservations>) reservationsRepository.findAll();
	}

	@Override
	public Reservations findById(int id) {
		 Optional<Reservations> optReservation = reservationsRepository.findById(id); 
		    if (optReservation.isPresent()) {
		        return optReservation.get();
		    } else {
		       throw new ResourceNotFoundException("Reservation", "Id", id);
		    }
	}

	@Override
	public Boolean deleteReservationsById(int id) {
		 Optional<Reservations> optReservation = reservationsRepository.findById(id); 
		 if (optReservation.isPresent()) {
			 reservationsRepository.delete(optReservation.get());
			 return true;
		    } else {
		       throw new ResourceNotFoundException("Reservation", "Id", id);
		    }
	}

	@Override
	public List<Reservations> findByName(String name) {
		return (List<Reservations>) reservationsRepository.findByName(name);
	}

	@Override
	public Reservations createReservation(Reservations reservation) {		
		MeetingRoom room = meetingRoomRepository.checkAvailability(reservation.getDateBegin(), reservation.getDateEnd(), reservation.getRoomId());		
		if(room != null){
			Reservations r = reservationsRepository.save(reservation);
			return r;
		} else
			return null;
	}
	
	
}
