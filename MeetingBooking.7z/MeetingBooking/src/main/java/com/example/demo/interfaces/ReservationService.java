package com.example.demo.interfaces;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entity.Reservations;


//@Service
//@Transactional
public interface ReservationService {
	public Reservations createReservation(Reservations reservation);
    public List<Reservations> getReservations();
    public Reservations findById(int id);
    public Boolean deleteReservationsById(int id);
    public List<Reservations> findByName(String name);
}